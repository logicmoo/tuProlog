﻿%NameSpace MyNameSpace
%ClassName MyClassName
